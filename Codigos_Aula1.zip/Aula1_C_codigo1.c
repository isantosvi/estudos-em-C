#include <stdio.h>

int main (){
	printf("Otaviano");
	return 0;
}
