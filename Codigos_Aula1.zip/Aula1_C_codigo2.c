# include <stdio.h>

int main (){
	float n1, n2;
	printf("Digite um valor: ");
	scanf("%f",&n1);
	printf("Digite um novo valor:");
	scanf("%f",&n2);
	printf("Resultado: %.2f ",n1+n2);
}
