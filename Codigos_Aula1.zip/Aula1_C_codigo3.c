# include <stdio.h>

int main(){
	float numero1, numero2;
	
	printf("Digite o primeiro valor: ");
	scanf("%f",&numero1);
	printf("Digite o segundo valor: ");
	scanf("%f",&numero2);
	
	if (numero1 == numero2)
		printf("Valores iguais!\n");
	else printf("Valores diferentes!\n");
	
}
