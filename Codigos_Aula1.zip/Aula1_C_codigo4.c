# include <stdio.h>

int main(){
	int valor;
	printf("Digite um n�mero: ");
	scanf("%d",&valor);
	
	if (valor > 10) 
		printf("Maior do que 10.");
	else if (valor == 10)
		printf("Igual a 10.");
	else printf("Menor do que 10");
	
	return 0;
}
