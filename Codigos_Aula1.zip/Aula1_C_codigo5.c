# include <stdio.h>

int main (){
	float nota1, nota2, nota3, media;
	
	printf("Informe a primeira nota: ");
	scanf("%f",&nota1);
	printf("Informe a segunda nota: ");
	scanf("%f",&nota2);
	printf("Informe a terceira nota: ");
	scanf("%f",&nota3);
	
	media = (nota1 + nota2 + nota3) /3;
	
	if (nota1>=60 && nota2 >=60 && nota3 >= 60)
		printf("Aprovado(a) por nota nas 3 disciplinas");
	// Valida��o com menor rigor
	else if (media >= 60)
		printf("Aprovado(a) pela media das notas");
	// Valida��o com menor rigor ainda (s� para testar o operador ||)
	else if (nota1 >=60 || nota2 >= 60 || nota3 >=60)
		printf("Aprovado(a) por ter ido bem em 1 disciplina.");
	else printf("Reprovado(a)");
	
	return 0;
}
